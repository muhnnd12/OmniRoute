using System;
using System.Collections.Generic;
using System.Globalization;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;

namespace FoundationSection
{
    /// <summary>
    /// يرسم مقطع الأساس الشريطي حسب الصورة.
    /// نقطة الأصل المحلية = منتصف أسفل الجلمود. المحور Y لفوق.
    /// </summary>
    internal class SectionBuilder
    {
        // ======== ثوابت التصميم (بالمتر) - عدّلها هنا إذا تريد ========
        const double W_JALMOOD = 2.00;        // عرض الجلمود (ثابت)
        const double W_HASSA = 1.50;          // عرض الحصى الخابط (ثابت)
        const double TAKEEB_OFFSET = 0.05;    // بروز التكعيب عن وجه الجدار (كل جهة)
        const double TAKEEB_WIDE_RATIO = 0.55;// نسبة الجزء العريض من ارتفاع التكعيب
        const double WALL_ABOVE = 0.50;       // ارتفاع الجدار فوق البتلو لحد خط القطع
        const double FLOOR_LEN = 1.20;        // طول الأرضية الظاهر يسار الجدار
        const double FLOOR_FILL = 0.10;       // سمك فرشة الأرضية (رمل/خرسانة)
        const double TILE_T = 0.05;           // سمك البلاط
        const double TILE_W = 0.30;           // عرض قطعة البلاط
        const double EARTH_LEN = 1.40;        // طول هاتش التربة يمين الأساس
        const double EARTH_T = 0.12;          // سمك هاتش التربة تحت G.L

        // true = يرسم حجارة الجلمود (خطوط مو هاتش). الافتراضي: بدون
        const bool DRAW_STONES = false;

        const string L_OUT = "FND_OUTLINE";
        const string L_HATCH = "FND_HATCH";
        const string L_DIM = "FND_DIM";
        const string L_TEXT = "FND_TEXT";

        readonly Database db;
        readonly Transaction tr;
        readonly BlockTableRecord btr;
        readonly FoundationParams p;
        readonly List<Entity> created = new List<Entity>();
        readonly double f;
        readonly double textH;
        ObjectId styleId;

        SectionBuilder(Database db, Transaction tr, FoundationParams p)
        {
            this.db = db; this.tr = tr; this.p = p;
            f = p.F;
            textH = 0.0035 * p.Scale * f;     // 3.5mm على الورق
            btr = (BlockTableRecord)tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite);
        }

        public static void Draw(Document doc, FoundationParams p, Point3d ucsPoint, Matrix3d ucs)
        {
            Database db = doc.Database;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                var b = new SectionBuilder(db, tr, p);
                b.Build();

                // من الاحداثيات المحلية الى UCS الحالي ثم WCS
                Matrix3d xf = ucs * Matrix3d.Displacement(ucsPoint.GetAsVector());
                foreach (Entity e in b.created) e.TransformBy(xf);
                tr.Commit();
            }
        }

        // ==================================================================
        void Build()
        {
            EnsureLayer(L_OUT, 7);
            EnsureLayer(L_HATCH, 8);
            EnsureLayer(L_DIM, 3);
            EnsureLayer(L_TEXT, 2);
            styleId = EnsureTextStyle("FND_TEXT", "Arial");

            // ---- المناسيب ----
            double y0 = 0;
            double y1 = y0 + p.HJalmood;
            double y2 = y1 + p.HHassa;
            double y3 = y2 + p.HAsas;            // G.L
            double y4 = y3 + p.HTakeeb;          // مستوى الأرضية = أسفل البتلو
            double y5 = y4 + p.HBitlu;           // أعلى البتلو
            double y6 = y5 + WALL_ABOVE * f;     // أعلى الجدار (خط القطع)
            double yw = y3 + p.HTakeeb * TAKEEB_WIDE_RATIO;  // أعلى الجزء العريض من التكعيب

            double wj = W_JALMOOD * f, wh = W_HASSA * f;
            double hw = p.WWall / 2.0, ha = p.WAsas / 2.0, ht = hw + TAKEEB_OFFSET * f;

            // ---- 1) الجلمود ----
            Rubble(-wj / 2, y0, wj / 2, y1);
            // ---- 2) الحصى الخابط ----
            Fill(-wh / 2, y1, wh / 2, y2);
            // ---- 3) الأساس ----
            Fill(-ha, y2, ha, y3);
            // ---- 4) التكعيب (جزء عريض + جزء بعرض الجدار) ----
            Fill(-ht, y3, ht, yw);
            Fill(-hw, yw, hw, y4);
            // ---- 5) البتلو ----
            Fill(-hw, y4, hw, y5);
            // ---- 6) الجدار فوق البتلو ----
            Fill(-hw, y5, hw, y6);

            // ---- خط القطع (Break line) أعلى الجدار ----
            AddLine(-hw - 0.15 * f, y6, hw + 0.15 * f, y6, L_OUT);
            var zz = new Polyline();
            zz.AddVertexAt(0, new Point2d(0.00 * f, y6 + 0.22 * f), 0, 0, 0);
            zz.AddVertexAt(1, new Point2d(-0.03 * f, y6 + 0.06 * f), 0, 0, 0);
            zz.AddVertexAt(2, new Point2d(0.05 * f, y6 + 0.04 * f), 0, 0, 0);
            zz.AddVertexAt(3, new Point2d(0.00 * f, y6 - 0.12 * f), 0, 0, 0);
            Add(zz, L_OUT);

            // ---- الأرضيات (يسار الجدار) ----
            double xl = -hw - FLOOR_LEN * f;
            double tt = TILE_T * f, tw = TILE_W * f;
            double fillT = Math.Min(FLOOR_FILL * f, 0.45 * p.HTakeeb);
            for (double x = xl; x < -hw - 1e-9; x += tw)
                AddRect(x, y4, Math.Min(x + tw, -hw), y4 + tt, L_OUT);        // بلاط
            Fill(xl, y4 - fillT, -hw, y4);               // فرشة

            // ---- هاتش التربة تحت G.L يمين الأساس ----
            double earthT = Math.Min(EARTH_T * f, p.HAsas);
            double xe = ha + EARTH_LEN * f;
            Fill(ha, y3 - earthT, xe, y3);

            // ---- النصوص ----
            AddText("G.L", new Point3d(ha + EARTH_LEN * 0.55 * f, y3 + 0.04 * f, 0),
                    textH * 1.4, Autodesk.AutoCAD.DatabaseServices.AttachmentPoint.BottomCenter);
            AddText(p.Arabic ? "الأرضيات" : "Flooring",
                    new Point3d((xl - hw) / 2, y4 + tt + 0.08 * f, 0),
                    textH * 1.4, Autodesk.AutoCAD.DatabaseServices.AttachmentPoint.BottomCenter);

            // ---- الأبعاد (ارتفاعات) على اليمين ----
            double xr = Math.Max(wj / 2, xe);
            double xd = xr + 0.40 * f;
            double[] ly = { y0, y1, y2, y3, y4, y5 };
            double[] lx = { wj / 2, wj / 2, wh / 2, xe, hw, hw };   // اقصى نقطة يمين عند كل منسوب
            string[] names = p.Arabic
                ? new[] { "ارتفاع الجلمود", "ارتفاع الحصى الخابط", "ارتفاع الأساس", "ارتفاع التكعيب", "ارتفاع البتلو" }
                : new[] { "Stone rubble height", "Compacted gravel height", "Foundation height", "Plinth wall height", "Plinth band height" };

            AddHeightDims(lx, ly, xd);
            for (int i = 0; i < 5; i++)
                AddText(names[i], new Point3d(xd + 0.20 * f, (ly[i] + ly[i + 1]) / 2, 0),
                        textH * 1.2, Autodesk.AutoCAD.DatabaseServices.AttachmentPoint.MiddleLeft);
        }

        // ==================================================================
        // أدوات الرسم
        // ==================================================================
        ObjectId Add(Entity e, string layer)
        {
            e.Layer = layer;
            btr.AppendEntity(e);
            tr.AddNewlyCreatedDBObject(e, true);
            created.Add(e);
            return e.ObjectId;
        }

        ObjectId AddRect(double x1, double y1, double x2, double y2, string layer)
        {
            var pl = new Polyline();
            pl.AddVertexAt(0, new Point2d(x1, y1), 0, 0, 0);
            pl.AddVertexAt(1, new Point2d(x2, y1), 0, 0, 0);
            pl.AddVertexAt(2, new Point2d(x2, y2), 0, 0, 0);
            pl.AddVertexAt(3, new Point2d(x1, y2), 0, 0, 0);
            pl.Closed = true;
            return Add(pl, layer);
        }

        void AddLine(double x1, double y1, double x2, double y2, string layer)
        {
            Add(new Line(new Point3d(x1, y1, 0), new Point3d(x2, y2, 0)), layer);
        }

        /// <summary>مستطيل فقط (بدون هاتش).</summary>
        void Fill(double x1, double y1, double x2, double y2)
        {
            AddRect(x1, y1, x2, y2, L_OUT);
        }

        /// <summary>الجلمود: مستطيل + حجارة مدورة (قطوع ناقصة) مرصوصة.</summary>
        void Rubble(double x1, double y1, double x2, double y2)
        {
            AddRect(x1, y1, x2, y2, L_OUT);
            if (!DRAW_STONES) return;
            var rnd = new Random(2026);
            double W = x2 - x1, H = y2 - y1;
            int rows = Math.Max(1, (int)Math.Round(H / (0.095 * f)));
            int cols = Math.Max(2, (int)Math.Round(W / (0.14 * f)));
            double ch = H / rows, cw = W / cols;
            for (int r = 0; r < rows; r++)
            {
                double cy = y1 + ch * (r + 0.5);
                if (r % 2 == 0)
                {
                    for (int c = 0; c < cols; c++) Stone(rnd, x1 + cw * (c + 0.5), cy, cw, ch);
                }
                else
                {
                    for (int c = 1; c < cols; c++) Stone(rnd, x1 + cw * c, cy, cw, ch);
                    Stone(rnd, x1 + cw * 0.25, cy, cw * 0.5, ch);
                    Stone(rnd, x2 - cw * 0.25, cy, cw * 0.5, ch);
                }
            }
        }

        void Stone(Random rnd, double cx, double cy, double cw, double ch)
        {
            cx += (rnd.NextDouble() - 0.5) * cw * 0.06;
            cy += (rnd.NextDouble() - 0.5) * ch * 0.06;
            double a = cw * (0.40 + 0.06 * rnd.NextDouble());
            double b = ch * (0.38 + 0.06 * rnd.NextDouble());
            double th = (rnd.NextDouble() - 0.5) * 0.45;       // +-13 درجة
            AddEllipse(cx, cy, a, b, th);
            if (rnd.NextDouble() < 0.45)                          // دائرة صغيرة داخل الحجر
                AddEllipse(cx + (rnd.NextDouble() - 0.5) * a * 0.5, cy + (rnd.NextDouble() - 0.5) * b * 0.5,
                           a * 0.30, b * 0.30, th + 0.4);
        }

        void AddEllipse(double cx, double cy, double a, double b, double th)
        {
            if (b > a) { double t = a; a = b; b = t; th += Math.PI / 2; }
            var major = new Vector3d(a * Math.Cos(th), a * Math.Sin(th), 0);
            Add(new Ellipse(new Point3d(cx, cy, 0), Vector3d.ZAxis, major, b / a, 0, 2 * Math.PI), L_HATCH);
        }

        string Fmt(double v)
        {
            if (f <= 1.0) return v.ToString("0.00", CultureInfo.InvariantCulture);
            if (f <= 100.0) return v.ToString("0.#", CultureInfo.InvariantCulture);
            return v.ToString("0", CultureInfo.InvariantCulture);
        }

        /// <summary>اربعة اشياء: خطوط امتداد، خط البعد، علامات ميل، ارقام الارتفاعات.</summary>
        void AddHeightDims(double[] lx, double[] ly, double xd)
        {
            double ext = 0.06 * f, t = textH * 0.5;
            for (int i = 0; i < ly.Length; i++)
            {
                AddLine(lx[i], ly[i], xd + ext, ly[i], L_DIM);                 // خط امتداد
                AddLine(xd - t, ly[i] - t, xd + t, ly[i] + t, L_DIM);          // علامة ميل
            }
            AddLine(xd, ly[0], xd, ly[ly.Length - 1], L_DIM);                  // خط البعد
            for (int i = 0; i < ly.Length - 1; i++)
                AddText(Fmt(ly[i + 1] - ly[i]), new Point3d(xd - textH * 0.7, (ly[i] + ly[i + 1]) / 2, 0),
                        textH, Autodesk.AutoCAD.DatabaseServices.AttachmentPoint.MiddleRight);
        }

        void AddText(string s, Point3d pos, double h, Autodesk.AutoCAD.DatabaseServices.AttachmentPoint ap)
        {
            var m = new MText
            {
                Contents = s,
                TextHeight = h,
                Location = pos,
                Attachment = ap,
                TextStyleId = styleId
            };
            Add(m, L_TEXT);
        }

        // ==================================================================
        // طبقات + ستايل نص
        // ==================================================================
        void EnsureLayer(string name, short aci)
        {
            var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            if (lt.Has(name)) return;
            lt.UpgradeOpen();
            var r = new LayerTableRecord
            {
                Name = name,
                Color = Color.FromColorIndex(ColorMethod.ByAci, aci)
            };
            lt.Add(r);
            tr.AddNewlyCreatedDBObject(r, true);
        }

        ObjectId EnsureTextStyle(string name, string font)
        {
            var tst = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
            if (tst.Has(name)) return tst[name];
            tst.UpgradeOpen();
            var r = new TextStyleTableRecord
            {
                Name = name,
                Font = new Autodesk.AutoCAD.GraphicsInterface.FontDescriptor(font, false, false, 0, 0)
            };
            ObjectId id = tst.Add(r);
            tr.AddNewlyCreatedDBObject(r, true);
            return id;
        }
    }
}
