using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace FoundationSection
{
    /// <summary>القيم المدخلة. كل الأبعاد بوحدة الرسم (m / cm / mm).</summary>
    internal class FoundationParams
    {
        public bool Arabic;
        public double F;          // وحدة الرسم لكل متر: 1 / 100 / 1000
        public double Scale;      // مقياس الرسم 1:Scale (لحجم النصوص)
        public double HJalmood;   // 1) ارتفاع الجلمود
        public double HHassa;     // 2) ارتفاع الحصى الخابط
        public double HAsas;      // 3) ارتفاع الأساس
        public double WAsas;      // 4) عرض الأساس
        public double WWall;      // 5) عرض الجدار
        public double HTakeeb;    // 6) ارتفاع التكعيب
        public double HBitlu;     // 7) ارتفاع البتلو
    }

    internal class FoundationDialog : Form
    {
        static readonly double[] Factors = { 1.0, 100.0, 1000.0 };
        static readonly string[] UnitNames = { "m", "cm", "mm" };

        readonly bool ar;
        double curF;
        TextBox tJ, tH, tA, tWA, tWW, tT, tB;
        ComboBox cUnit, cScale;

        public FoundationParams Result { get; private set; }

        string T(string arText, string enText) { return ar ? arText : enText; }

        public FoundationDialog(bool arabic, int unitIndex)
        {
            ar = arabic;
            curF = Factors[unitIndex];

            Text = T("مقطع أساس شريطي", "Strip Footing Section");
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterScreen;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            Font = new Font(ar ? "Tahoma" : "Segoe UI", 10f);
            ClientSize = new Size(1100, 482);

            // ---- الصورة ----
            var pic = new PictureBox
            {
                Left = 10, Top = 10, Width = 702, Height = 459,
                SizeMode = PictureBoxSizeMode.Zoom,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.FromArgb(33, 40, 48)
            };
            LoadImage(pic);
            Controls.Add(pic);

            // ---- الجدول ----
            var tl = new TableLayoutPanel
            {
                Left = 725, Top = 10, Width = 365, Height = 400,
                ColumnCount = 2,
                AutoSize = false
            };
            tl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            tl.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 90f));
            if (ar) tl.RightToLeft = RightToLeft.Yes;

            tJ  = AddRow(tl, T("1) ارتفاع الجلمود", "1) Stone rubble height") + Note("2.00"), 0.30);
            tH  = AddRow(tl, T("2) ارتفاع الحصى الخابط", "2) Compacted gravel height") + Note("1.50"), 0.30);
            tA  = AddRow(tl, T("3) ارتفاع الأساس", "3) Foundation height"), 0.50);
            tWA = AddRow(tl, T("4) عرض الأساس", "4) Foundation width"), 0.60);
            tWW = AddRow(tl, T("5) عرض الجدار", "5) Wall width"), 0.25);
            tT  = AddRow(tl, T("6) ارتفاع التكعيب", "6) Plinth wall height"), 0.65);
            tB  = AddRow(tl, T("7) ارتفاع البتلو", "7) Plinth band height"), 0.15);

            cUnit = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 80 };
            cUnit.Items.AddRange(UnitNames);
            cUnit.SelectedIndex = unitIndex;
            cUnit.SelectedIndexChanged += OnUnitChanged;
            AddControlRow(tl, T("وحدة الرسم", "Drawing unit"), cUnit);

            cScale = new ComboBox { DropDownStyle = ComboBoxStyle.DropDown, Width = 80 };
            cScale.Items.AddRange(new object[] { "10", "20", "25", "50", "100" });
            cScale.Text = "20";
            AddControlRow(tl, T("مقياس الرسم 1 :", "Drawing scale 1 :"), cScale);

            var credit = new Label
            {
                Text = T("تم برمجة هذا الأمر من قبل\nالمهندس المدني: نورالحسين\nانستغرام: eng_nour_1",
                         "This command was programmed by\nCivil Engineer: Nooralhusin\nInstagram: eng_nour_1"),
                AutoSize = true,
                ForeColor = Color.DimGray,
                Padding = new Padding(0, 14, 0, 0)
            };
            int crow = tl.RowCount++;
            tl.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            tl.Controls.Add(credit, 0, crow);
            tl.SetColumnSpan(credit, 2);

            // قيم البداية تتحول للوحدة المختارة
            ApplyFactorToDefaults(curF);
            Controls.Add(tl);

            // ---- الأزرار ----
            var btnOk = new Button
            {
                Text = T("رسم", "Draw"), Width = 110, Height = 34,
                DialogResult = DialogResult.None
            };
            btnOk.Click += OnOk;
            var btnCancel = new Button
            {
                Text = T("إلغاء", "Cancel"), Width = 110, Height = 34,
                DialogResult = DialogResult.Cancel
            };
            var fl = new FlowLayoutPanel
            {
                Left = 725, Top = 430, Width = 365, Height = 40,
                FlowDirection = FlowDirection.LeftToRight
            };
            if (ar) fl.RightToLeft = RightToLeft.Yes;
            fl.Controls.Add(btnOk);
            fl.Controls.Add(btnCancel);
            Controls.Add(fl);

            AcceptButton = btnOk;
            CancelButton = btnCancel;
        }

        // ------------------------------------------------------------------
        string Note(string meters)
        {
            return "\n" + T("(العرض ثابت = " + meters + " م)", "(width fixed = " + meters + " m)");
        }

        void LoadImage(PictureBox pic)
        {
            try
            {
                string dir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                string file = Path.Combine(dir, "Resources", ar ? "foundation_ar.png" : "foundation_en.png");
                if (File.Exists(file))
                {
                    using (var s = File.OpenRead(file))
                    using (var img = Image.FromStream(s))
                        pic.Image = new Bitmap(img);
                }
            }
            catch { }
        }

        TextBox AddRow(TableLayoutPanel tl, string label, double defaultMeters)
        {
            var tb = new TextBox { Width = 80, Tag = defaultMeters };
            AddControlRow(tl, label, tb);
            return tb;
        }

        void AddControlRow(TableLayoutPanel tl, string label, Control c)
        {
            var lb = new Label
            {
                Text = label, AutoSize = true, Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(0, 4, 0, 4)
            };
            c.Anchor = AnchorStyles.None;
            int row = tl.RowCount++;
            tl.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            tl.Controls.Add(lb, 0, row);
            tl.Controls.Add(c, 1, row);
        }

        void ApplyFactorToDefaults(double f)
        {
            foreach (TextBox tb in new[] { tJ, tH, tA, tWA, tWW, tT, tB })
                tb.Text = Fmt(((double)tb.Tag) * f);
        }

        static string Fmt(double v)
        {
            return Math.Round(v, 4).ToString("0.####", CultureInfo.InvariantCulture);
        }

        // تغيير الوحدة يحوّل القيم المكتوبة تلقائياً
        void OnUnitChanged(object sender, EventArgs e)
        {
            double newF = Factors[cUnit.SelectedIndex];
            double ratio = newF / curF;
            foreach (TextBox tb in new[] { tJ, tH, tA, tWA, tWW, tT, tB })
            {
                double v;
                if (TryParse(tb.Text, out v)) tb.Text = Fmt(v * ratio);
            }
            curF = newF;
        }

        // يقبل الفاصلة والأرقام العربية (٠١٢٣...)
        static bool TryParse(string s, out double v)
        {
            v = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            var sb = new System.Text.StringBuilder();
            foreach (char ch in s.Trim())
            {
                if (ch >= '\u0660' && ch <= '\u0669') sb.Append((char)('0' + (ch - '\u0660')));
                else if (ch >= '\u06F0' && ch <= '\u06F9') sb.Append((char)('0' + (ch - '\u06F0')));
                else if (ch == ',' || ch == '\u066B' || ch == '\u060C') sb.Append('.');
                else sb.Append(ch);
            }
            return double.TryParse(sb.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out v);
        }

        void OnOk(object sender, EventArgs e)
        {
            double j, h, a, wa, ww, t, b, sc;
            bool ok = TryParse(tJ.Text, out j) & TryParse(tH.Text, out h) & TryParse(tA.Text, out a)
                    & TryParse(tWA.Text, out wa) & TryParse(tWW.Text, out ww)
                    & TryParse(tT.Text, out t) & TryParse(tB.Text, out b)
                    & TryParse(cScale.Text, out sc);
            if (!ok || j <= 0 || h <= 0 || a <= 0 || wa <= 0 || ww <= 0 || t <= 0 || b <= 0 || sc <= 0)
            {
                Warn(T("كل القيم لازم تكون أرقام أكبر من صفر.", "All values must be numbers greater than zero."));
                return;
            }

            double f = Factors[cUnit.SelectedIndex];
            if (wa / f >= 1.5)
            {
                Warn(T("عرض الأساس لازم يكون أقل من 1.50 م (عرض الحصى الخابط).",
                       "Foundation width must be less than 1.50 m (the gravel layer width)."));
                return;
            }
            if (ww >= wa)
            {
                Warn(T("عرض الجدار لازم يكون أقل من عرض الأساس.",
                       "Wall width must be less than the foundation width."));
                return;
            }

            Result = new FoundationParams
            {
                Arabic = ar, F = f, Scale = sc,
                HJalmood = j, HHassa = h, HAsas = a, WAsas = wa, WWall = ww, HTakeeb = t, HBitlu = b
            };
            DialogResult = DialogResult.OK;
            Close();
        }

        void Warn(string msg)
        {
            MessageBox.Show(this, msg, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button1,
                ar ? MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading : 0);
        }
    }
}
