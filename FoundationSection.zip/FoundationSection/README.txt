FoundationSection - اضافة اوتوكاد لرسم مقطع اساس شريطي
=========================================================

الامر: FOUNDATION
1) يسألك اللغة (Arabic / English)
2) تظهر نافذة بالصورة + 7 حقول (+ وحدة الرسم + مقياس الرسم)
3) تحدد نقطة المقطع (منتصف اسفل الجلمود) فيرسم المقطع بالهاتش والابعاد

البناء (Visual Studio 2022):
- افتح FoundationSection.csproj
- غيّر AcadDir حسب مسار اوتوكادك
- اوتوكاد 2021-2024  -> TargetFramework = net48
- اوتوكاد 2025-2026  -> TargetFramework = net8.0-windows
- Build -> يطلع FoundationSection.dll مع مجلد Resources (الصورتين) جنبه

التشغيل: بالاوتوكاد اكتب NETLOAD واختار الـ DLL، بعدها اكتب FOUNDATION.

القيم الثابتة (عرض الجلمود 2.00م، الحصى 1.50م، بروز التكعيب...) 
موجودة بأول SectionBuilder.cs وتگدر تعدلها.
