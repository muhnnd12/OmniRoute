@echo off
cd /d "%~dp0"
set "ACAD=C:\Program Files\Autodesk\AutoCAD 2022"
set "CSC=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"

if not exist "%ACAD%\acmgd.dll" (
  echo.
  echo ERROR: AutoCAD folder not found:
  echo %ACAD%
  echo Open BUILD.bat with Notepad and fix the line that starts with: set "ACAD=
  echo.
  pause
  exit /b 1
)

echo Building FoundationSection.dll ...
"%CSC%" /nologo /target:library /platform:x64 /out:FoundationSection.dll /r:"%ACAD%\acmgd.dll" /r:"%ACAD%\acdbmgd.dll" /r:"%ACAD%\accoremgd.dll" /r:System.Windows.Forms.dll /r:System.Drawing.dll *.cs

echo.
if exist FoundationSection.dll (
  echo SUCCESS: FoundationSection.dll is ready in this folder.
) else (
  echo FAILED: copy the error lines above and send them to Claude.
)
echo.
pause
