using System;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;
using WinForms = System.Windows.Forms;

[assembly: CommandClass(typeof(FoundationSection.FoundationCommand))]
[assembly: ExtensionApplication(typeof(FoundationSection.FoundationCommand))]

namespace FoundationSection
{
    public class FoundationCommand : IExtensionApplication
    {
        public void Initialize()
        {
            try
            {
                Document doc = AcApp.DocumentManager.MdiActiveDocument;
                if (doc != null)
                    doc.Editor.WriteMessage("\nFoundationSection loaded. Command: FOUNDATION\n");
            }
            catch { }
        }

        public void Terminate() { }

        [CommandMethod("FOUNDATION")]
        public void Run()
        {
            Document doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) return;
            Editor ed = doc.Editor;

            // ---- 1) اللغة -------------------------------------------------
            var ko = new PromptKeywordOptions("\nSelect language");
            ko.Keywords.Add("Arabic");
            ko.Keywords.Add("English");
            ko.Keywords.Default = "Arabic";
            ko.AppendKeywordsToMessage = true;
            ko.AllowNone = true;
            PromptResult kr = ed.GetKeywords(ko);
            if (kr.Status != PromptStatus.OK && kr.Status != PromptStatus.None) return;
            bool arabic = kr.Status == PromptStatus.None || kr.StringResult != "English";

            // ---- 2) النافذة -----------------------------------------------
            var dlg = new FoundationDialog(arabic, DefaultUnitIndex(doc.Database));
            if (AcApp.ShowModalDialog(dlg) != WinForms.DialogResult.OK) return;
            FoundationParams p = dlg.Result;

            // ---- 3) نقطة الإدراج ------------------------------------------
            var ppo = new PromptPointOptions(arabic
                ? "\nحدد نقطة المقطع (منتصف أسفل الجلمود): "
                : "\nSpecify section point (bottom-center of the rubble layer): ");
            PromptPointResult pr = ed.GetPoint(ppo);
            if (pr.Status != PromptStatus.OK) return;

            // ---- 4) الرسم -------------------------------------------------
            try
            {
                SectionBuilder.Draw(doc, p, pr.Value, ed.CurrentUserCoordinateSystem);
                ed.WriteMessage(arabic ? "\nتم رسم مقطع الأساس.\n" : "\nFoundation section created.\n");
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage("\nFOUNDATION error: " + ex.Message + "\n");
            }
        }

        // 0 = m , 1 = cm , 2 = mm  حسب INSUNITS للرسم
        static int DefaultUnitIndex(Database db)
        {
            switch (db.Insunits)
            {
                case UnitsValue.Centimeters: return 1;
                case UnitsValue.Millimeters: return 2;
                default: return 0;
            }
        }
    }
}
